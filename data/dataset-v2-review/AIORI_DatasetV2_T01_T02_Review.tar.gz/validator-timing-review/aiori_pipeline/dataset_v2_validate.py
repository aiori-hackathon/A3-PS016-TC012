"""Draft Dataset v2 delivery checks. Never creates labels or trains a model.

Checks exported evidence, not hidden simulator-state equivalence. Even a fully
passing delivery still requires pairing/outcome review before training.
"""
import argparse
import csv
import hashlib
import io
import json
import math
import stat
import sys
import zipfile
from collections import Counter, defaultdict
from pathlib import Path, PurePosixPath

from .dataset_v2_audit import plan_rows
from .ml import FEATURES, dump, fresh_output
from .pilot import RAW, canonical, check_raw, digest
from .pipeline import ContractError, FLOATS, INTS, SCHEMAS, require, write_csv

CONTRACT_ID = 'paired-pilot-v2-delivery-draft'
SCHEMA_ID = 'ue-candidate-v2-draft'
MANIFEST_FIELDS = ['pair_id', 'status', 'reason', 'stay_folder', 'handover_folder']
FEATURE_FIELDS = [
    'decision_id', 'pair_id', 'run_id', 'decision_time_s', 'imsi',
    'serving_cell_id', 'candidate_cell_id', *FEATURES, 'input_status', 'input_reason',
    'serving_measurement_time_s', 'candidate_measurement_time_s',
    'previous_measurement_time_s', 'mobility_measurement_time_s',
    'feature_event_index', 'decision_event_index', 'history_reset_reason',
    'feature_schema_id', 'config_sha256', 'source_sha256',
    'episode_id', 'scenario_family_id', 'scenario_variant_id', 'split_group_id',
    'planned_split', 'seed', 'rng_run', 'stream_map_id', 'label_protocol_id', 'followup_policy_id',
]
ACTION_FIELDS = ['decision_id', 'requested_action', 'actual_action', 'request_time_s',
                 'target_cell_id', 'attempt_id', 'gate_reason', 'hold_end_s']
METRICS = {
    'throughput_mbps': 'Mbps', 'total_excess_gap_s': 's',
    'transmitted_packets': 'count', 'received_packets': 'count',
    'packet_loss_rate': 'fraction', 'handover_failures': 'count',
    'ping_pong_events': 'count', 'service_failures': 'count',
}
OUTCOME_FIELDS = ['decision_id', 'window_start_s', 'window_end_s', 'observation_status'] + [
    field for metric in METRICS for field in (metric, metric + '_status', metric + '_definition_id')]
SHARED_FIELDS = [
    'scenario_family_id', 'geometry_variant', 'speed_kmh', 'seed', 'rng_run',
    'source_sha256', 'ns3_version', 'resolved_geometry', 'resolved_mobility',
    'resolved_radio', 'scheduler', 'traffic', 'rng_stream_assignments',
    'followup_policy', 'trace_coverage',
]
RESET_EVENTS = {'HANDOVER_COMPLETED', 'CONNECTION_REESTABLISHED', 'TRAJECTORY_DISCONTINUITY'}
EPS = 1e-9


def num(value, name, minimum=None):
    try:
        result = float(value)
    except (TypeError, ValueError) as exc:
        raise ContractError(f'{name}: expected finite number') from exc
    require(math.isfinite(result), f'{name}: nonfinite number')
    require(minimum is None or result >= minimum, f'{name}: below minimum')
    return result


def integer(value, name):
    result = num(value, name, 0)
    require(result.is_integer(), f'{name}: expected nonnegative integer')
    return int(result)


def close(a, b, name, tolerance=1e-5):
    require(abs(num(a, name) - num(b, name)) <= tolerance, f'{name}: disagrees with raw evidence')


def table(text, fields):
    reader = csv.DictReader(io.StringIO(text, newline=''))
    headers = reader.fieldnames or []
    require(headers and len(headers) == len(set(headers)) and set(fields) <= set(headers),
            'Missing/duplicate CSV headers: ' + ','.join(sorted(set(fields) - set(headers))))
    rows = list(reader)
    require(all(None not in r and all(v is not None for v in r.values()) for r in rows), 'Malformed CSV row')
    return [{k: v.strip() for k, v in r.items()} for r in rows]


class Delivery:
    """Bounded read-only ZIP/directory reader; no extraction or supplied code execution."""
    def __init__(self, path):
        self.path = Path(path).resolve()
        self.archive = None
        self.hashes = {}
        try:
            if self.path.is_dir():
                paths = list(self.path.rglob('*'))
                require(not any(p.is_symlink() or not p.resolve().is_relative_to(self.path) for p in paths),
                        'Unsafe directory member')
                self.files = {p.relative_to(self.path).as_posix(): p for p in paths if p.is_file()}
                sizes = [p.stat().st_size for p in self.files.values()]
            else:
                self.archive = zipfile.ZipFile(self.path)
                entries = self.archive.infolist()
                require(len({e.filename for e in entries}) == len(entries), 'Duplicate ZIP member')
                for e in entries:
                    p = PurePosixPath(e.filename)
                    require(not p.is_absolute() and '..' not in p.parts and '\\' not in e.filename and ':' not in e.filename,
                            'Unsafe ZIP member')
                    require(not stat.S_ISLNK(e.external_attr >> 16) and not e.flag_bits & 1, 'Unsupported ZIP member')
                self.files = {e.filename: e for e in entries if not e.is_dir()}
                sizes = [e.file_size for e in self.files.values()]
            require(len(self.files) <= 10000 and sum(sizes) <= 512 * 1024 * 1024, 'Delivery exceeds intake limit')
            roots = [str(PurePosixPath(n).parent) for n in self.files if PurePosixPath(n).name == 'pilot_manifest.csv']
            require(len(roots) == 1, 'Expected one pilot_manifest.csv root')
            self.prefix = '' if roots[0] == '.' else roots[0] + '/'
        except Exception:
            self.close()
            raise

    def close(self):
        if self.archive:
            self.archive.close()

    def read(self, name):
        p = PurePosixPath(name)
        require(not p.is_absolute() and '..' not in p.parts and '\\' not in name and ':' not in name, 'Unsafe requested path')
        key = self.prefix + name
        require(key in self.files, f'Missing file: {name}')
        value = self.archive.read(key) if self.archive else self.files[key].read_bytes()
        checksum = hashlib.sha256(value).hexdigest()
        require(self.hashes.setdefault(name, checksum) == checksum, f'Input changed: {name}')
        return value

    def rows(self, name, fields):
        return table(self.read(name).decode('utf-8-sig'), fields)

    def json(self, name):
        value = json.loads(self.read(name).decode('utf-8-sig'))
        require(isinstance(value, dict), f'{name}: expected object')
        return value

    def raw(self, folder):
        result = {}
        for name in RAW:
            fields = SCHEMAS[name].split(',') + ([] if name == 'traffic.csv' else ['event_index'])
            rows = self.rows(folder + '/' + name, fields)
            for r in rows:
                for k in fields:
                    if k in INTS or k == 'event_index':
                        r[k] = integer(r[k], k)
                    elif k in FLOATS:
                        r[k] = num(r[k], k)
            result[name] = sorted(rows, key=lambda r: (r.get('time_s', 0), r.get('event_index', 0)))
        check_raw(result)
        require(all(r['time_s'] >= 0 for name in RAW[:-1] for r in result[name]), 'Negative raw timestamp')
        return result


def order(row):
    return num(row['time_s'], 'time_s', 0), integer(row['event_index'], 'event_index')


def in_band(delta, anchor):
    return (delta >= anchor['minimum_delta_db'] and
            (delta <= anchor['maximum_delta_db'] if anchor['maximum_inclusive'] else delta < anchor['maximum_delta_db']))


def check_event_clock(raw, resets):
    times = {}
    for row in [r for name in RAW[:-1] for r in raw[name]] + resets:
        t, index = order(row)
        require(index not in times or times[index] == t, 'Event index reused at a different time')
        times[index] = t
    ordered = sorted(times.items())
    require(all(a[1] <= b[1] for a, b in zip(ordered, ordered[1:])), 'Event clock contradicts timestamps')


def assess_features(row, raw, resets):
    """Recompute available inputs from causal raw rows, retaining missing trend."""
    status = row['input_status']
    require(status in {'AVAILABLE', 'STALE', 'UNAVAILABLE'}, 'Invalid input_status')
    if status != 'AVAILABLE':
        require(row['input_reason'], 'Rejected input needs input_reason')
        return {'eligible': False, 'status': status, 'reason': row['input_reason']}
    require(not row['input_reason'], 'AVAILABLE input must have blank input_reason')
    require(row['feature_schema_id'] == SCHEMA_ID, 'Unexpected feature schema')
    t = num(row['decision_time_s'], 'decision_time_s', 0)
    ue = integer(row['imsi'], 'imsi')
    src = integer(row['serving_cell_id'], 'serving_cell_id')
    dst = integer(row['candidate_cell_id'], 'candidate_cell_id')
    fi, di = (integer(row[k], k) for k in ['feature_event_index', 'decision_event_index'])
    require(fi < di and src != dst, 'Invalid feature/action order or equal cells')
    cutoff = (t, fi)
    radio = [r for r in raw['radio.csv'] if r['imsi'] == ue and order(r) < cutoff]
    snapshots = defaultdict(list)
    for r in radio:
        snapshots[r['time_s']].append(r)
    history = []
    invalid_at = []
    for rt, rows in sorted(snapshots.items()):
        serving = [r for r in rows if r['is_serving_cell'] == '1']
        neighbours = [r for r in rows if r['is_serving_cell'] == '0']
        if len(serving) != 1 or not neighbours or len({r['serving_cell_id'] for r in rows}) != 1:
            invalid_at.append(rt)
            continue
        candidate = max(neighbours, key=lambda r: (r['rsrp_dbm'], -r['measured_cell_id']))
        history.append((rt, serving[0], candidate, max(order(r) for r in rows)))
    require(history, 'No complete causal radio snapshot')
    rt, serving, candidate, current_order = history[-1]
    require(0 <= t - rt <= .2 + EPS, 'Stale radio input must be marked STALE')
    require(serving['measured_cell_id'] == src and candidate['measured_cell_id'] == dst,
            'Wrong serving cell or strongest measured neighbour')
    for k in ['serving_measurement_time_s', 'candidate_measurement_time_s']:
        require(num(row[k], k) <= t, 'Future source timestamp')
        close(row[k], rt, k, EPS)
    close(row['serving_rsrp_dbm'], serving['rsrp_dbm'], 'serving_rsrp_dbm')
    close(row['candidate_rsrp_dbm'], candidate['rsrp_dbm'], 'candidate_rsrp_dbm')
    delta = candidate['rsrp_dbm'] - serving['rsrp_dbm']
    close(row['rsrp_delta_db'], delta, 'rsrp_delta_db')
    mobility = [r for r in raw['mobility.csv'] if r['imsi'] == ue and order(r) < cutoff]
    require(mobility, 'No causal mobility input')
    latest = max(mobility, key=order)
    require(0 <= t - latest['time_s'] <= .2 + EPS, 'Stale mobility input must be marked STALE')
    require(num(row['mobility_measurement_time_s'], 'mobility timestamp') <= t, 'Future mobility timestamp')
    close(row['mobility_measurement_time_s'], latest['time_s'], 'mobility timestamp', EPS)
    close(num(row['speed_mps'], 'speed_mps', 0), latest['speed_mps'], 'speed_mps')
    require(0 <= num(row['mobility_age_s'], 'mobility_age_s') <= .2 + EPS, 'Invalid mobility age')
    close(row['mobility_age_s'], t - latest['time_s'], 'mobility_age_s', EPS)
    # Use the immediately preceding complete snapshot. Returning to a prior cell
    # pair never permits recovering a slope from an older matching pair.
    previous = history[-2] if len(history) > 1 else None
    valid = previous is not None
    reset_reasons = set()
    for r in resets:
        require(r['event'] in RESET_EVENTS, 'Invalid history reset event')
    all_resets = list(resets) + [dict(r, event='HANDOVER_COMPLETED') for r in raw['handovers.csv'] if r['event'] == 'SUCCESS']
    if previous:
        pt, ps, pc, previous_order = previous
        valid = (0 < rt - pt <= .4 + EPS and ps['measured_cell_id'] == src and pc['measured_cell_id'] == dst)
        if ps['measured_cell_id'] != src or pc['measured_cell_id'] != dst:
            reset_reasons.add('CELL_PAIR_CHANGED')
        if any(pt < x <= t for x in invalid_at):
            valid = False
            reset_reasons.add('INCOMPLETE_HISTORY')
        for r in all_resets:
            if integer(r['imsi'], 'reset imsi') == ue and previous_order < order(r) < cutoff:
                valid = False
                reset_reasons.add(r['event'])
        if rt - pt > .4 + EPS:
            reset_reasons.add('HISTORY_GAP')
    else:
        reset_reasons.add('NO_PREVIOUS_SNAPSHOT')
    flag = integer(row['trend_available'], 'trend_available')
    require(flag in {0, 1} and bool(flag) == valid, 'Incorrect trend availability after history/reset checks')
    if valid:
        require(not row['history_reset_reason'], 'Valid trend must have blank history_reset_reason')
        close(row['previous_measurement_time_s'], previous[0], 'previous_measurement_time_s', EPS)
        previous_delta = previous[2]['rsrp_dbm'] - previous[1]['rsrp_dbm']
        close(row['delta_slope_db_per_s'], (delta - previous_delta) / (rt - previous[0]), 'delta_slope_db_per_s')
    else:
        require(row['delta_slope_db_per_s'] == '' and row['previous_measurement_time_s'] == '',
                'Unavailable trend must be blank, not zero/substituted')
        require(bool(row['history_reset_reason']), 'Unavailable trend needs history_reset_reason')
    return {'eligible': True, 'status': status, 'actual_delta_db': delta,
            'reset_reasons': sorted(reset_reasons),
            'vector': [None if row[k] == '' else num(row[k], k) for k in FEATURES]}


def validate_outcomes(row, raw, cfg):
    t = num(cfg['decision_time_s'], 'decision time', 0)
    close(row['window_start_s'], t, 'window_start_s', EPS)
    close(row['window_end_s'], t + 1, 'window_end_s', EPS)
    require(row['observation_status'] in {'COMPLETE', 'CENSORED', 'UNKNOWN'}, 'Invalid observation_status')
    statuses = {}
    for metric in METRICS:
        status = row[metric + '_status']
        require(status in {'OBSERVED', 'UNKNOWN', 'CENSORED', 'UNSUPPORTED'}, f'Invalid {metric} status')
        statuses[metric] = status
        if status == 'OBSERVED':
            value = num(row[metric], metric, 0)
            require(row[metric + '_definition_id'], f'{metric}: missing definition ID')
            if METRICS[metric] == 'count':
                integer(value, metric)
            if metric == 'packet_loss_rate':
                require(value <= 1, 'packet_loss_rate exceeds 1')
            if metric == 'service_failures':
                require(cfg['shared_configuration']['trace_coverage'].get('service_events') is True,
                        'Observed service failures require explicit trace coverage')
        else:
            require(row[metric] == '', f'{metric}: unknown/censored/unsupported must be blank, never zero')
    if row['observation_status'] == 'COMPLETE':
        received = [r for r in raw['packets.csv'] if r['imsi'] == integer(cfg['imsi'], 'imsi') and t <= r['time_s'] < t + 1]
        if statuses['throughput_mbps'] == 'OBSERVED':
            close(row['throughput_mbps'], sum(r['payload_bytes'] for r in received) * 8 / 1e6, 'throughput_mbps', 1e-6)
        if statuses['received_packets'] == 'OBSERVED':
            close(row['received_packets'], len(received), 'received_packets', 0)
    # Other outcome semantics remain a human review gate. A diagnostic gap or
    # sequence hole is never silently promoted to outage or end-to-end loss.
    return statuses


def validate_rollout(source, folder, action, pair_id, planned):
    cfg = source.json(folder + '/run_config.json')
    require(cfg.get('pilot_contract_id') == CONTRACT_ID and cfg.get('feature_schema_id') == SCHEMA_ID, 'Wrong draft contract/schema ID')
    require(cfg.get('pair_id') == pair_id and cfg.get('action') == action, 'Config pair/action mismatch')
    shared = cfg['shared_configuration']
    require(all(k in shared and shared[k] not in ('', None, {}, []) for k in SHARED_FIELDS), 'Incomplete resolved shared configuration')
    for key, value in [('scenario_family_id', planned['family_id']), ('geometry_variant', 'A'),
                       ('seed', 1), ('rng_run', 1001), ('speed_kmh', planned['speed_kmh'])]:
        require(shared[key] == value, f'Unexpected pilot {key}')
    for key in ['radio', 'mobility', 'handovers', 'packets', 'history_events']:
        require(shared['trace_coverage'].get(key) is True, f'Missing trace coverage: {key}')
    require(cfg.get('shared_configuration_sha256') == digest(shared), 'Shared configuration checksum mismatch')
    require(num(cfg['decision_time_s'], 'decision time', 0) >= 1, 'Decision precedes minimum warmup')
    raw = source.raw(folder)
    resets = source.rows(folder + '/history_events.csv', ['time_s', 'event_index', 'imsi', 'event'])
    features = source.rows(folder + '/decision_features.csv', FEATURE_FIELDS)
    clock_features = [dict(time_s=f['decision_time_s'], event_index=f[key]) for f in features
                      for key in ['feature_event_index', 'decision_event_index'] if f[key] != '']
    check_event_clock(raw, resets + clock_features)
    branch = [r for r in features if r['decision_id'] == cfg.get('branch_decision_id')]
    require(len(branch) == 1, 'Expected one branch decision row')
    seen = set()
    assessed = None
    for row in features:
        require(row['decision_id'] and row['decision_id'] not in seen, 'Duplicate/empty decision ID')
        seen.add(row['decision_id'])
        require(row['pair_id'] == pair_id and row['run_id'] == cfg['run_id'], 'Feature identity mismatch')
        require(row['config_sha256'] == source.hashes[folder + '/run_config.json'], 'Feature config hash mismatch')
        require(row['source_sha256'] == shared['source_sha256'], 'Feature source hash mismatch')
        required_metadata = ['episode_id', 'scenario_variant_id', 'stream_map_id', 'label_protocol_id', 'followup_policy_id']
        if row['input_status'] == 'AVAILABLE':
            required_metadata += ['serving_measurement_time_s', 'candidate_measurement_time_s',
                                  'mobility_measurement_time_s', 'feature_event_index', 'decision_event_index']
        require(all(row[k] for k in required_metadata), 'Missing feature metadata')
        require(row['scenario_family_id'] == planned['family_id'] and row['split_group_id'] == planned['split_group_id']
                and row['planned_split'] == 'train', 'Feature scenario/split mismatch')
        require(integer(row['seed'], 'seed') == 1 and integer(row['rng_run'], 'rng_run') == 1001, 'Feature RNG mismatch')
        result = assess_features(row, raw, resets)
        if row is branch[0]:
            assessed = result
    row = branch[0]
    require(assessed['eligible'], 'Branch input is stale/unavailable; not a usable pair')
    close(row['decision_time_s'], cfg['decision_time_s'], 'branch time', EPS)
    require(integer(row['imsi'], 'imsi') == integer(cfg['imsi'], 'imsi'), 'Branch UE mismatch')
    require(in_band(assessed['actual_delta_db'], planned), 'Actual margin outside requested band')
    actions = source.rows(folder + '/decision_actions.csv', ACTION_FIELDS)
    actions = [a for a in actions if a['decision_id'] == row['decision_id']]
    require(len(actions) == 1, 'Missing/duplicate branch action')
    a = actions[0]
    require(a['requested_action'] == action and a['actual_action'] == action, 'Action unsupported/unavailable or not executed')
    close(a['hold_end_s'], num(cfg['decision_time_s'], 't') + .2, 'hold_end_s', EPS)
    if action == 'handover':
        close(a['request_time_s'], cfg['decision_time_s'], 'Immediate handover time', EPS)
        require(integer(a['target_cell_id'], 'target cell') == integer(row['candidate_cell_id'], 'candidate'), 'Requested target mismatch')
        starts = [h for h in raw['handovers.csv'] if h['event'] == 'START' and h['attempt_id'] == a['attempt_id'] and h['imsi'] == integer(cfg['imsi'], 'imsi')]
        require(len(starts) == 1 and starts[0]['target_cell_id'] == integer(a['target_cell_id'], 'target'), 'Requested handover lacks actual START evidence')
        require(starts[0]['source_cell_id'] == integer(row['serving_cell_id'], 'serving'), 'Handover source mismatch')
        # ns-3 schedules the handover request with a 1 ms delay.
        # Pilot review tolerance: up to 2 ms from decision to START.
        # Retain actual timestamps; do not rewrite the raw evidence.
        start_delay = starts[0]['time_s'] - num(
            cfg['decision_time_s'], 'decision time', 0)
        require(
            0 <= start_delay <= 0.002,
            'Handover START outside 2 ms causal scheduling window'
        )
    else:
        require(not a['attempt_id'] and not a['request_time_s'], 'STAY must not contain an immediate request')
        require(not any(h['event'] == 'START' and h['imsi'] == integer(cfg['imsi'], 'imsi') and
                        num(cfg['decision_time_s'], 't') <= h['time_s'] < num(cfg['decision_time_s'], 't') + .2
                        for h in raw['handovers.csv']), 'STAY violated 200 ms hold')
    outcomes = source.rows(folder + '/action_outcomes.csv', OUTCOME_FIELDS)
    outcomes = [o for o in outcomes if o['decision_id'] == row['decision_id']]
    require(len(outcomes) == 1, 'Missing/duplicate branch outcome')
    statuses = validate_outcomes(outcomes[0], raw, cfg)
    # Equal-timestamp action-side events must be excluded using event order.
    cutoff = (num(row['decision_time_s'], 't'), integer(row['decision_event_index'], 'decision event'))
    prefixes = {name: canonical([r for r in raw[name] if order(r) < cutoff]) for name in RAW[:-1]}
    prefixes['traffic.csv'] = canonical(raw['traffic.csv'])
    prefixes['history_events.csv'] = canonical([r for r in resets if order(r) < cutoff])
    require(not any(h['event'] == 'START' and h['imsi'] == integer(cfg['imsi'], 'imsi') and order(h) < cutoff and
                    not any(e['imsi'] == h['imsi'] and e['attempt_id'] == h['attempt_id'] and e['event'] in {'SUCCESS', 'FAILURE'} and order(e) < cutoff
                            for e in raw['handovers.csv']) for h in raw['handovers.csv']), 'Unfinished handover at branch point')
    return {'shared': shared, 'branch': row, 'features': assessed, 'prefixes': prefixes, 'outcomes': statuses,
            'input_status_counts': dict(Counter(f['input_status'] for f in features))}


def validate_delivery(path, output, plan_path='configs/dataset_v2_simulations.draft.json'):
    cfg = json.loads(Path(plan_path).read_text(encoding='utf-8'))
    planned = {r['proposed_pair_key']: r for r in plan_rows(cfg) if r['pilot_batch'] == 'yes'}
    out = fresh_output(output, [path, plan_path])
    source = Delivery(path)
    report = {'contract_id': CONTRACT_ID, 'input': str(Path(path).resolve()), 'pairs': [],
              'errors': [], 'training_ready': False, 'labels_generated': 0,
              'pairing_definition_verified': False, 'outcome_definitions_verified': False,
              'limitations': ['Export matching cannot prove hidden simulator-state equality or branch-independent RNG use.',
                              'Follow-up behaviour, outcome definitions and simulator support require joint review.',
                              'The pilot validates data generation; it is not a reliable ML training benchmark.']}
    try:
        manifest = source.rows('pilot_manifest.csv', MANIFEST_FIELDS)
        keys = [r['pair_id'] for r in manifest]
        require(len(set(keys)) == len(keys) and set(keys) == set(planned), 'Manifest must account for exactly the 12 approved slots')
        used_folders = set()
        fingerprints = []
        for slot in manifest:
            pair_id, status = slot['pair_id'], slot['status']
            item = {'pair_id': pair_id, 'status': status, 'export_checks_passed': False}
            report['pairs'].append(item)
            try:
                require(status in {'AVAILABLE', 'UNSUPPORTED', 'UNAVAILABLE', 'PENDING'}, 'Invalid slot status')
                if status != 'AVAILABLE':
                    require(slot['reason'], 'Non-available slot needs reason')
                    item['reason'] = slot['reason']
                    continue
                require(not slot['reason'], 'AVAILABLE slot must have blank reason')
                branches = []
                for action in ['stay', 'handover']:
                    folder = slot[action + '_folder']
                    require(folder and folder not in used_folders, 'Empty/reused rollout folder')
                    used_folders.add(folder)
                    branches.append(validate_rollout(source, folder, action, pair_id, planned[pair_id]))
                stay, handover = branches
                require(stay['shared'] == handover['shared'], 'Paired shared configurations differ')
                require(stay['prefixes'] == handover['prefixes'], 'Pre-decision raw history differs')
                fields = ['decision_time_s', 'imsi', 'serving_cell_id', 'candidate_cell_id',
                          'serving_measurement_time_s', 'candidate_measurement_time_s',
                          'previous_measurement_time_s', 'mobility_measurement_time_s',
                          'feature_event_index', 'decision_event_index', 'history_reset_reason',
                          'episode_id', 'scenario_family_id', 'scenario_variant_id', 'split_group_id',
                          'planned_split', 'seed', 'rng_run', 'stream_map_id', 'label_protocol_id', 'followup_policy_id']
                require(all(stay['branch'][k] == handover['branch'][k] for k in fields) and
                        stay['features']['vector'] == handover['features']['vector'], 'Pre-decision features differ')
                item.update(export_checks_passed=True, actual_delta_db=stay['features']['actual_delta_db'],
                            outcome_statuses={a: b['outcomes'] for a, b in zip(['stay', 'handover'], branches)},
                            input_status_counts={a: b['input_status_counts'] for a, b in zip(['stay', 'handover'], branches)})
                fingerprints.append(tuple(None if x is None else round(x, 6) for x in stay['features']['vector']))
            except (ContractError, KeyError, TypeError, ValueError, OSError) as exc:
                item['error'] = str(exc)
                report['errors'].append({'pair_id': pair_id, 'error': str(exc)})
        report['slot_counts'] = dict(Counter(r['status'] for r in manifest))
        report['matched_export_pairs'] = len(fingerprints)
        report['unique_input_vectors_rounded_6dp'] = len(set(fingerprints))
        report['all_slots_available_and_export_checks_passed'] = len(fingerprints) == 12 and not report['errors']
    except (ContractError, KeyError, TypeError, ValueError, OSError) as exc:
        report['errors'].append({'error': str(exc)})
    finally:
        report['read_file_sha256'] = dict(sorted(source.hashes.items()))
        source.close()
    report['structural_checks_passed'] = not report['errors']
    dump(out / 'validation.json', report)
    return report


def export_template(output, plan_path='configs/dataset_v2_simulations.draft.json'):
    cfg = json.loads(Path(plan_path).read_text(encoding='utf-8'))
    rows = [dict(zip(MANIFEST_FIELDS, [r['proposed_pair_key'], 'PENDING', 'NOT_YET_GENERATED', '', '']))
            for r in plan_rows(cfg) if r['pilot_batch'] == 'yes']
    out = fresh_output(output, [plan_path])
    write_csv(out / 'pilot_manifest.csv', rows, MANIFEST_FIELDS)
    for name, fields in [('decision_features.csv', FEATURE_FIELDS), ('decision_actions.csv', ACTION_FIELDS),
                         ('action_outcomes.csv', OUTCOME_FIELDS),
                         ('history_events.csv', ['time_s', 'event_index', 'imsi', 'event'])]:
        write_csv(out / (name + '.headers-only'), [], fields)
    return {'status': 'template_no_simulated_data', 'slots': len(rows), 'output': str(out)}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    for name in ['check', 'template']:
        p = commands.add_parser(name)
        p.add_argument('--plan', default='configs/dataset_v2_simulations.draft.json')
        p.add_argument('--output', required=True)
        if name == 'check':
            p.add_argument('--input', required=True)
    args = parser.parse_args(argv)
    try:
        result = (validate_delivery(args.input, args.output, args.plan) if args.command == 'check'
                  else export_template(args.output, args.plan))
        print(json.dumps({k: v for k, v in result.items() if k != 'read_file_sha256'}, indent=2))
        return 2 if result.get('errors') else 0
    except (ContractError, OSError, ValueError, zipfile.BadZipFile) as exc:
        print(str(exc), file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
